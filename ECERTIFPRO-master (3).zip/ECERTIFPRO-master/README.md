# 🏆 ECERTIFPRO

<div align="center">
  <img src="public/icon-192x192.png" alt="ECERTIFPRO Logo" width="120" height="120">
  
  **منصة الشهادات المهنية الإلكترونية**
  
  [![Next.js](https://img.shields.io/badge/Next.js-15-black?style=flat-square&logo=next.js)](https://nextjs.org/)
  [![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)](https://www.typescriptlang.org/)
  [![Prisma](https://img.shields.io/badge/Prisma-6-2D3748?style=flat-square&logo=prisma)](https://www.prisma.io/)
  [![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC?style=flat-square&logo=tailwind-css)](https://tailwindcss.com/)
</div>

---

## 📝 عن المنصة

ECERTIFPRO هي منصة شهادات مهنية إلكترونية متكاملة تتيح للمتعلمين الحصول على شهادات معتمدة في مجالات متعددة.

### 🎯 الشهادات المتاحة

| الشهادة | السعر | المستوى |
|---------|-------|---------|
| مطور Al-Marjaa المعتمد | $199 | متوسط |
| خبير AI بالعربية | $299 | متقدم |
| مطور ويب محترف | $249 | متوسط |
| محلل بيانات معتمد | $279 | متوسط |
| خبير أمن سيبراني | $349 | خبير |

---

## ✨ المميزات

### 🎓 نظام الشهادات
- اختبارات تفاعلية مع مؤقت
- نتائج فورية
- شهادات مع QR Code للتحقق
- تحميل الشهادات بصيغة PNG

### 💳 نظام الدفع
- دعم Stripe
- دعم PayPal (جاهز للتفعيل)
- إيصالات تلقائية

### 👨‍💼 لوحة تحكم المشرف
- إدارة المستخدمين
- إدارة الشهادات
- إدارة المدفوعات
- تقارير وإحصائيات

### 🔔 نظام الإشعارات
- **إشعارات البريد الإلكتروني**: ترحيب، شهادات، دفع، تذكيرات
- **WebSocket**: إشعارات فورية في الوقت الحقيقي
- **Push Notifications**: إشعارات المتصفح

### 📱 PWA
- قابل للتثبيت على الهاتف
- يعمل بدون إنترنت
- إشعارات Push

---

## 🚀 التثبيت

```bash
# استنساخ المشروع
git clone https://github.com/radhwendalyhamdouni/ECERTIFPRO.git
cd ECERTIFPRO

# تثبيت الحزم
bun install

# إعداد قاعدة البيانات
bun run db:push
bun run db:seed

# تشغيل الخادم
bun run dev
```

---

## ⚙️ متغيرات البيئة

أنشئ ملف `.env`:

```env
# Database
DATABASE_URL="file:./db/custom.db"

# App
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Stripe
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..."

# SMTP
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="your-email@gmail.com"
SMTP_PASS="your-app-password"

# VAPID Keys (Push Notifications)
VAPID_PUBLIC_KEY="..."
VAPID_PRIVATE_KEY="..."
```

---

## 📁 هيكل المشروع

```
ECERTIFPRO/
├── prisma/
│   ├── schema.prisma      # قاعدة البيانات
│   └── seed.ts            # البيانات الأولية
├── public/
│   ├── manifest.json      # PWA manifest
│   └── sw.js              # Service Worker
├── src/
│   ├── app/
│   │   ├── admin/         # لوحة المشرف
│   │   ├── api/           # API endpoints
│   │   ├── auth/          # تسجيل الدخول
│   │   ├── certificates/  # الشهادات
│   │   ├── checkout/      # الدفع
│   │   ├── dashboard/     # لوحة المستخدم
│   │   ├── exam/          # الاختبارات
│   │   └── notifications/ # الإشعارات
│   ├── components/        # المكونات
│   └── lib/               # المكتبات
└── vercel.json            # إعدادات Vercel
```

---

## 🛠️ API Endpoints

| Endpoint | Method | الوصف |
|----------|--------|-------|
| `/api/auth` | POST | المصادقة |
| `/api/certificates` | GET/POST | الشهادات |
| `/api/users` | GET/POST/PUT | المستخدمين |
| `/api/payments` | GET/POST/PUT | المدفوعات |
| `/api/notifications` | GET/POST/PUT/DELETE | الإشعارات |
| `/api/exams` | GET/POST | الاختبارات |
| `/api/verify/[id]` | GET | التحقق من شهادة |
| `/api/email` | POST | إرسال بريد |
| `/api/push` | POST | Push notifications |

---

## 👨‍💼 المؤسس

**رضوان دالي حمدوني**

📧 **البريد**: almarjaa.project@hotmail.com

🌐 **الموقع**: [ECERTIFPRO.COM](https://ecertifpro.com)

---

## 📄 الترخيص

جميع الحقوق محفوظة © 2024 ECERTIFPRO

---

## 🚀 النشر على Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/radhwendalyhamdouni/ECERTIFPRO)

### خطوات النشر:

1. انقر على الزر أعلاه
2. اربط حسابك بـ GitHub
3. أضف متغيرات البيئة
4. انقر Deploy

---

<div align="center">
  
**🏆 ECERTIFPRO - شهادات مهنية معتمدة**

Made with ❤️ in Arabic

</div>
